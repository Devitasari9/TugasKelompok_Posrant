package com.example.posrant

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
