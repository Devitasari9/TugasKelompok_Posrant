class AppConfig {
  static String baseUrl = "";
  static String token = "";
}
